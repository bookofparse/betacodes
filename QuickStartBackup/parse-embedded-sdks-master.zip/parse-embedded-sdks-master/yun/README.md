# Parse Arduino Yún SDK

The Parse Arduino Yún SDK has moved to [ParsePlatform/Parse-SDK-Arduino GitHub
repository](https://www.github.com/ParsePlatform/Parse-SDK-Arduino).

We highly recommend using Arduino Software (IDE). Please refer to the [Parse Arduino Quickstart](https://www.parse.com/apps/quickstart#embedded/arduinoyun) to get started!
