var searchData=
[
  ['add',['add',['../class_parse_object_create.html#aef6a2f97213830e6bed87072582cacd2',1,'ParseObjectCreate::add(const char *key, int d)'],['../class_parse_object_create.html#a387eeceadeff3ee518bb0d7799e64079',1,'ParseObjectCreate::add(const char *key, double d)'],['../class_parse_object_create.html#acfe8ab5db42e693229572f3ac026e59d',1,'ParseObjectCreate::add(const char *key, const char *s)'],['../class_parse_object_create.html#aaae9d6ef53dfab038595042411ea87b5',1,'ParseObjectCreate::add(const char *key, bool b)']]],
  ['addgeopoint',['addGeoPoint',['../class_parse_object_create.html#a26e0614e39b039b2bea157215f559c24',1,'ParseObjectCreate']]],
  ['addjsonvalue',['addJSONValue',['../class_parse_object_create.html#a396da194e7cea55e5a791420cfa3d3e9',1,'ParseObjectCreate::addJSONValue(const char *key, const char *json)'],['../class_parse_object_create.html#ae6930463963df8a280177050ac91c231',1,'ParseObjectCreate::addJSONValue(const char *key, const String &amp;json)']]]
];
