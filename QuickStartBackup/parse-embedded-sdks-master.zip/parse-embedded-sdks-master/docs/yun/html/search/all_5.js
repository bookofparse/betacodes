var searchData=
[
  ['nextobject',['nextObject',['../class_parse_response.html#ad6b1c9d00fcf27a7387d1d9da957751e',1,'ParseResponse']]],
  ['nextpush',['nextPush',['../class_parse_client.html#a83d0d717e2b9f548dc4de48f9c49458e',1,'ParseClient']]]
];
