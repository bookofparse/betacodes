var searchData=
[
  ['parse_20embedded_20c_20sdk',['Parse Embedded C SDK',['../index.html',1,'']]]
];
